import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("autentico.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    region TEXT NOT NULL,
    is_verified_local BOOLEAN DEFAULT 0,
    avatar_url TEXT
  );

  CREATE TABLE IF NOT EXISTS recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    region TEXT NOT NULL,
    difficulty TEXT NOT NULL,
    time_minutes INTEGER NOT NULL,
    cover_image_url TEXT,
    cover_video_url TEXT,
    is_verified BOOLEAN DEFAULT 0,
    author_id INTEGER NOT NULL,
    FOREIGN KEY(author_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS ingredients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recipe_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    quantity TEXT NOT NULL,
    FOREIGN KEY(recipe_id) REFERENCES recipes(id)
  );

  CREATE TABLE IF NOT EXISTS recipe_steps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recipe_id INTEGER NOT NULL,
    step_number INTEGER NOT NULL,
    instruction TEXT NOT NULL,
    image_url TEXT,
    video_url TEXT,
    FOREIGN KEY(recipe_id) REFERENCES recipes(id)
  );

  CREATE TABLE IF NOT EXISTS verifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recipe_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    status TEXT NOT NULL, -- 'approved', 'rejected'
    notes TEXT,
    FOREIGN KEY(recipe_id) REFERENCES recipes(id),
    FOREIGN KEY(user_id) REFERENCES users(id)
  );
`);

// Seed data if empty
const userCount = db.prepare("SELECT COUNT(*) as count FROM users").get() as { count: number };
if (userCount.count === 0) {
  const insertUser = db.prepare("INSERT INTO users (name, region, is_verified_local, avatar_url) VALUES (?, ?, ?, ?)");
  insertUser.run("Nonna Maria", "Campania, Italy", 1, "https://picsum.photos/seed/nonna/100/100");
  insertUser.run("Luigi", "Lazio, Italy", 1, "https://picsum.photos/seed/luigi/100/100");
  insertUser.run("Giuseppe", "Lazio, Italy", 1, "https://picsum.photos/seed/giuseppe/100/100");
  insertUser.run("Francesca", "Lazio, Italy", 1, "https://picsum.photos/seed/francesca/100/100");

  const insertRecipe = db.prepare(`
    INSERT INTO recipes (title, description, region, difficulty, time_minutes, cover_image_url, is_verified, author_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const recipeResult = insertRecipe.run(
    "Authentic Spaghetti alla Carbonara",
    "The real Roman way. No cream, no garlic, just guanciale, pecorino, eggs, and black pepper.",
    "Lazio, Italy",
    "Medium",
    25,
    "https://images.unsplash.com/photo-1612889837130-9b4b9b9b9b9b?q=80&w=1200&auto=format&fit=crop",
    1,
    2
  );
  const recipeId = recipeResult.lastInsertRowid;

  const insertIngredient = db.prepare("INSERT INTO ingredients (recipe_id, name, quantity) VALUES (?, ?, ?)");
  insertIngredient.run(recipeId, "Guanciale", "150g");
  insertIngredient.run(recipeId, "Spaghetti", "400g");
  insertIngredient.run(recipeId, "Egg yolks", "4");
  insertIngredient.run(recipeId, "Pecorino Romano", "50g");
  insertIngredient.run(recipeId, "Black pepper", "to taste");

  const insertStep = db.prepare("INSERT INTO recipe_steps (recipe_id, step_number, instruction, image_url, video_url) VALUES (?, ?, ?, ?, ?)");
  
  const carbonaraSteps = [
    "Cut 150g guanciale into thick strips.",
    "Place guanciale in a cold pan.",
    "Cook on medium heat until crispy.",
    "Remove pan from heat. Set aside.",
    "Put 4 egg yolks in a bowl.",
    "Add 50g grated Pecorino Romano.",
    "Add plenty of black pepper.",
    "Whisk into a thick paste.",
    "Fill a pot with water.",
    "Bring water to a rolling boil.",
    "Add 50g of coarse salt.",
    "Drop in 400g of spaghetti.",
    "Set a timer for 8 minutes.",
    "Save one cup of pasta water.",
    "Drain the spaghetti.",
    "Toss hot pasta in the guanciale pan.",
    "Stir in the egg mixture off-heat.",
    "Add pasta water for a creamy sauce."
  ];

  carbonaraSteps.forEach((instruction, index) => {
    insertStep.run(recipeId, index + 1, instruction, null, null);
  });

  const insertVerification = db.prepare("INSERT INTO verifications (recipe_id, user_id, status, notes) VALUES (?, ?, ?, ?)");
  insertVerification.run(recipeId, 2, "approved", "Perfetto!");
  insertVerification.run(recipeId, 3, "approved", "This is how my grandmother made it.");
  insertVerification.run(recipeId, 4, "approved", "No cream, exactly right.");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));

  // API Routes
  app.get("/api/users", (req, res) => {
    const users = db.prepare("SELECT * FROM users").all();
    res.json(users);
  });

  app.get("/api/recipes", (req, res) => {
    const recipes = db.prepare(`
      SELECT r.*, u.name as author_name, u.avatar_url as author_avatar,
             (SELECT COUNT(*) FROM verifications v WHERE v.recipe_id = r.id AND v.status = 'approved') as verification_count
      FROM recipes r
      JOIN users u ON r.author_id = u.id
      ORDER BY r.id DESC
    `).all();
    res.json(recipes);
  });

  app.get("/api/recipes/:id", (req, res) => {
    const recipe = db.prepare(`
      SELECT r.*, u.name as author_name, u.avatar_url as author_avatar,
             (SELECT COUNT(*) FROM verifications v WHERE v.recipe_id = r.id AND v.status = 'approved') as verification_count
      FROM recipes r
      JOIN users u ON r.author_id = u.id
      WHERE r.id = ?
    `).get(req.params.id);

    if (!recipe) {
      return res.status(404).json({ error: "Recipe not found" });
    }

    const ingredients = db.prepare("SELECT * FROM ingredients WHERE recipe_id = ?").all(req.params.id);
    const steps = db.prepare("SELECT * FROM recipe_steps WHERE recipe_id = ? ORDER BY step_number ASC").all(req.params.id);
    const verifications = db.prepare(`
      SELECT v.*, u.name as verifier_name, u.avatar_url as verifier_avatar
      FROM verifications v
      JOIN users u ON v.user_id = u.id
      WHERE v.recipe_id = ?
    `).all(req.params.id);

    res.json({ ...recipe, ingredients, steps, verifications });
  });

  app.post("/api/recipes", (req, res) => {
    const { title, description, region, difficulty, time_minutes, cover_image_url, cover_video_url, author_id, ingredients, steps } = req.body;
    
    const insertRecipe = db.prepare(`
      INSERT INTO recipes (title, description, region, difficulty, time_minutes, cover_image_url, cover_video_url, author_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    const info = insertRecipe.run(title, description, region, difficulty, time_minutes, cover_image_url, cover_video_url, author_id);
    const recipeId = info.lastInsertRowid;

    if (ingredients && Array.isArray(ingredients)) {
      const insertIngredient = db.prepare("INSERT INTO ingredients (recipe_id, name, quantity) VALUES (?, ?, ?)");
      ingredients.forEach((ing: any) => {
        insertIngredient.run(recipeId, ing.name, ing.quantity);
      });
    }

    const insertStep = db.prepare("INSERT INTO recipe_steps (recipe_id, step_number, instruction, image_url, video_url) VALUES (?, ?, ?, ?, ?)");
    steps.forEach((step: any, index: number) => {
      insertStep.run(recipeId, index + 1, step.instruction, step.image_url, step.video_url || null);
    });

    res.json({ id: recipeId });
  });

  app.post("/api/recipes/:id/verify", (req, res) => {
    const { user_id, status, notes } = req.body;
    const recipe_id = req.params.id;

    const insertVerification = db.prepare("INSERT INTO verifications (recipe_id, user_id, status, notes) VALUES (?, ?, ?, ?)");
    insertVerification.run(recipe_id, user_id, status, notes);

    // Check if we have 3 approvals
    const approvals = db.prepare("SELECT COUNT(*) as count FROM verifications WHERE recipe_id = ? AND status = 'approved'").get(recipe_id) as { count: number };
    if (approvals.count >= 3) {
      db.prepare("UPDATE recipes SET is_verified = 1 WHERE id = ?").run(recipe_id);
    }

    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
