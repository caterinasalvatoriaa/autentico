import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus } from 'lucide-react';
import { useAppContext } from '../data/AppContext';
import RecipeCard from '../components/RecipeCard';

export default function HomeFeed() {
  const { recipes, users, toggleLike, toggleSave, savedRecipes } = useAppContext();
  const navigate = useNavigate();

  return (
    <div className="max-w-md mx-auto bg-[#FAF7F2] min-h-screen pb-20 pt-4">
      {/* Header */}
      <div className="flex items-center justify-between px-4 mb-6">
        <h1 className="text-3xl font-serif font-medium text-[#1A1A1A]">Autentico</h1>
        <button 
          onClick={() => navigate('/add')}
          className="w-10 h-10 rounded-full bg-[#C4614A] text-white flex items-center justify-center hover:bg-[#A34E3A] transition-colors shadow-sm"
        >
          <Plus size={24} />
        </button>
      </div>

      {/* Feed */}
      <div className="flex flex-col gap-6">
        {recipes.map(recipe => {
          const author = users.find(u => u.id === recipe.author_id);
          if (!author) return null;
          const isSaved = savedRecipes.includes(recipe.id);

          return (
            <RecipeCard
              key={recipe.id}
              recipe={recipe}
              author={author}
              isSaved={isSaved}
              toggleLike={toggleLike}
              toggleSave={toggleSave}
            />
          );
        })}
      </div>
    </div>
  );
}
