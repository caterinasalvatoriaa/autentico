import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, Sparkles, AlertTriangle } from 'lucide-react';
import { useAppContext } from '../data/AppContext';
import { Recipe } from '../data/mockData';

export default function RecipeDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { recipes } = useAppContext();
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(true);
  const [checkedIngredients, setCheckedIngredients] = useState<Set<string>>(new Set());

  useEffect(() => {
    const found = recipes.find(r => r.id === id);
    setRecipe(found || null);
    setLoading(false);
  }, [id, recipes]);

  const toggleIngredient = (ingredientName: string) => {
    const newChecked = new Set(checkedIngredients);
    if (newChecked.has(ingredientName)) {
      newChecked.delete(ingredientName);
    } else {
      newChecked.add(ingredientName);
    }
    setCheckedIngredients(newChecked);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen bg-[#FAF7F2]">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-[#1A1A1A]"></div>
      </div>
    );
  }

  if (!recipe) {
    return <div className="text-center mt-20 font-sans text-[#1A1A1A]">Recipe not found.</div>;
  }

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#1A1A1A] font-sans pb-32">
      {/* Hero Section */}
      <div className="relative h-[60vh] w-full">
        <img
          src={recipe.cover_image_url || "https://picsum.photos/seed/food/1200/800"}
          alt={recipe.title}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        
        <button 
          onClick={() => navigate(-1)} 
          className="absolute top-6 left-6 z-20 p-2 text-white hover:opacity-70 transition-opacity"
        >
          <ChevronLeft size={32} strokeWidth={1.5} />
        </button>

        <div className="absolute bottom-12 left-6 right-6 text-white z-10">
          <h1 className="text-5xl md:text-6xl font-serif font-medium leading-tight mb-3 tracking-tight">
            {recipe.title}
          </h1>
          <span className="text-sm font-sans tracking-widest uppercase opacity-90">
            {recipe.region}
          </span>
        </div>
      </div>

      {/* Content Card sliding up */}
      <motion.div 
        initial={{ y: 40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="relative -mt-8 bg-[#FAF7F2] rounded-t-3xl px-6 md:px-12 pt-12 max-w-3xl mx-auto"
      >
        {/* Ingredients Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-serif mb-8 text-[#1A1A1A]">Ingredients</h2>
          <div className="space-y-4">
            {recipe.ingredients?.map((ing, idx) => {
              const isChecked = checkedIngredients.has(ing.name);
              return (
                <div 
                  key={idx} 
                  className="flex items-center gap-4 cursor-pointer group"
                  onClick={() => toggleIngredient(ing.name)}
                >
                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors shrink-0 ${isChecked ? 'bg-[#C4614A] border-[#C4614A]' : 'border-[#1A1A1A]/30 group-hover:border-[#1A1A1A]'}`}>
                    {isChecked && (
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M2.5 6L5 8.5L9.5 3.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    )}
                  </div>
                  <span className={`text-lg transition-all duration-300 flex items-center gap-2 flex-wrap ${isChecked ? 'line-through text-[#1A1A1A]/40' : 'text-[#1A1A1A]'}`}>
                    {ing.name} 
                    <span className="opacity-60">— {ing.qty} {ing.unit}</span>
                    {(ing as any).uncertain && (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-[#C4614A] bg-[#C4614A]/10 px-2 py-0.5 rounded-full no-underline">
                        <AlertTriangle size={12} />
                        Uncertain quantity
                      </span>
                    )}
                  </span>
                </div>
              );
            })}
          </div>
          {recipe.authenticity_notes && recipe.authenticity_notes.length > 0 && (
            <div className="mt-8 p-4 bg-[#E5E0D8]/30 rounded-xl">
              <h3 className="font-medium mb-2 text-sm uppercase tracking-wider">Authenticity Notes</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                {recipe.authenticity_notes.map((note, i) => (
                  <li key={i}>{note}</li>
                ))}
              </ul>
            </div>
          )}
        </section>

        {/* Method Section */}
        <section>
          <h2 className="text-3xl font-serif mb-10 text-[#1A1A1A]">Method</h2>
          <div className="space-y-16">
            {recipe.steps?.map((step, idx) => (
              <div key={idx} className="relative">
                <div className="flex flex-col md:flex-row gap-4 md:gap-8">
                  <div className="font-serif text-6xl text-[#1A1A1A]/10 leading-none select-none">
                    {step.step_number.toString().padStart(2, '0')}
                  </div>
                  <div className="flex-1 pt-2">
                    <p className="text-lg leading-relaxed text-[#1A1A1A] mb-4">
                      {step.instruction}
                    </p>
                    <button className="flex items-center gap-2 text-sm font-medium text-[#C4614A] hover:opacity-70 transition-opacity">
                      <Sparkles size={16} />
                      Check with AI
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </motion.div>

      {/* Start Cooking FAB */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-30">
        <Link
          to={`/recipe/${recipe.id}/cook`}
          className="bg-[#C4614A] text-white px-8 py-4 rounded-full font-sans font-medium tracking-wide flex items-center gap-2 hover:bg-[#A34E3A] transition-colors shadow-lg"
        >
          Start Cooking
        </Link>
      </div>
    </div>
  );
}
