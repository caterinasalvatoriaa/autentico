import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, MapPin, Sparkles, Edit2, CheckCircle, X, AlertTriangle } from 'lucide-react';
import { useAppContext } from '../data/AppContext';
import { motion, AnimatePresence } from 'framer-motion';
import { GoogleGenAI } from '@google/genai';

export default function AddRecipe() {
  const { addRecipe, currentUser } = useAppContext();
  const navigate = useNavigate();

  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [rawText, setRawText] = useState('');
  const [region, setRegion] = useState('');
  const [loadingText, setLoadingText] = useState('Reading your recipe...');
  const [generatedRecipe, setGeneratedRecipe] = useState<any>(null);
  const [finalRecipe, setFinalRecipe] = useState<any>(null);
  const [requestVerification, setRequestVerification] = useState(false);
  const [coverImage, setCoverImage] = useState<string | null>(null);
  const [acceptedChanges, setAcceptedChanges] = useState<number[]>([]);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [imageError, setImageError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const generateRecipeImage = async (recipeName: string, description: string) => {
    try {
      setImageError(null);
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const prompt = `A professional food photography shot of "${recipeName}". ${description}. The exact words "${recipeName}" MUST be written prominently and elegantly in the image, perhaps on a rustic menu card, a label, or beautifully integrated into the scene. Warm lighting, shallow depth of field, rustic Italian aesthetic, shot from slightly above, on a natural wood or marble surface. Soft, warm color palette with terracotta and cream tones (#C4614A, #FAF7F2). Painterly, slightly editorial style, Ottolenghi cookbook style.`;
      
      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: '1:1',
        },
      });

      if (response.generatedImages && response.generatedImages.length > 0) {
        const base64EncodeString = response.generatedImages[0].image.imageBytes;
        const imageUrl = `data:image/jpeg;base64,${base64EncodeString}`;
        setCoverImage(imageUrl);
      } else {
        setImageError("No image returned from API");
      }
    } catch (error: any) {
      console.error("Error generating image:", error);
      setImageError(error.message || "Failed to generate image");
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCoverImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTransform = async () => {
    if (!rawText.trim()) return;
    
    setStep(2);
    
    const loadingTexts = [
      "Reading your recipe...",
      "Splitting into micro-steps...",
      "Analyzing ingredients...",
      "Verifying authenticity markers..."
    ];
    let i = 0;
    const interval = setInterval(() => {
      i = (i + 1) % loadingTexts.length;
      setLoadingText(loadingTexts[i]);
    }, 1500);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const prompt = `You are a master culinary expert and recipe editor for Autentico, an app for authentic world recipes. Transform the user's raw recipe text into structured JSON.
      
      CRITICAL RULES FOR BETTER RECIPES:
      1. Authenticity is paramount. Use traditional methods and ingredients.
      2. Break the recipe down into highly specific, single-action micro-steps (max 8 words per instruction).
      3. Extract precise cooking times and temperatures.
      4. Add professional culinary tips in the "authenticity_notes".
      5. BE FAITHFUL TO THE USER'S INPUT. Do not invent ingredients. If a quantity is missing or uncertain, flag it as "uncertain": true.
      6. Track all significant changes you make (e.g., adding a quantity, splitting a step, adding a timing hint) in the "ai_changes" array.
      
      Output strictly as JSON with this structure:
      {
        "name": "dish name",
        "region": "specific region/city",
        "description": "Short engaging description",
        "ingredients": [
          { "name": "ingredient name", "qty": "amount", "unit": "unit (g, ml, etc)", "uncertain": boolean }
        ],
        "steps": [
          {
            "action": "Short action (max 8 words)",
            "detail": "Optional detail like 'Medium heat' or '10 mins'",
            "icon": "One of: pot, boil, knife, whisk, pan, colander, plate, salt, pasta, timer, cup, bowl",
            "timerSeconds": 600
          }
        ],
        "authenticity_notes": ["Note 1", "Note 2"],
        "ai_changes": [
          {
            "type": "quantity_added" | "step_split" | "timing_added" | "uncertain",
            "original": "original text snippet",
            "modified": "exact string present in the generated JSON above",
            "description": "Explanation of the change"
          }
        ]
      }
      
      Raw text:
      ${rawText}`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        }
      });

      let jsonStr = response.text?.trim() || '{}';
      jsonStr = jsonStr.replace(/^```json\s*/i, '').replace(/\s*```$/i, '');
      const parsed = JSON.parse(jsonStr);
      
      clearInterval(interval);
      setGeneratedRecipe(parsed);

      if (!coverImage) {
        setIsGeneratingImage(true);
        generateRecipeImage(parsed.name, parsed.description).finally(() => setIsGeneratingImage(false));
      }
      
      if (parsed.ai_changes && parsed.ai_changes.length > 0) {
        setAcceptedChanges(parsed.ai_changes.map((_: any, i: number) => i));
        setStep(3);
      } else {
        setFinalRecipe(parsed);
        setStep(4);
      }

    } catch (error) {
      console.error("Error transforming recipe:", error);
      clearInterval(interval);
      const fallback = {
        name: "Generated Recipe",
        region: region || "Unknown Region",
        description: "A delicious AI-generated recipe.",
        ingredients: [{ name: "Ingredient 1", qty: "1", unit: "cup", uncertain: false }],
        steps: [{ action: "Mix ingredients in bowl.", detail: null, icon: "bowl" }],
        authenticity_notes: ["This is a fallback recipe."],
        ai_changes: []
      };
      setGeneratedRecipe(fallback);
      setFinalRecipe(fallback);
      setStep(4);
    }
  };

  const applyChanges = () => {
    let jsonStr = JSON.stringify(generatedRecipe);
    
    generatedRecipe.ai_changes?.forEach((change: any, i: number) => {
      if (!acceptedChanges.includes(i)) {
        // Simple string replacement to revert the change
        if (change.modified && change.original) {
          jsonStr = jsonStr.replace(change.modified, change.original);
        }
      }
    });
    
    try {
      const revertedRecipe = JSON.parse(jsonStr);
      setFinalRecipe(revertedRecipe);
    } catch (e) {
      console.error("Error reverting changes", e);
      setFinalRecipe(generatedRecipe);
    }
    setStep(4);
  };

  const toggleChange = (index: number) => {
    if (acceptedChanges.includes(index)) {
      setAcceptedChanges(acceptedChanges.filter(i => i !== index));
    } else {
      setAcceptedChanges([...acceptedChanges, index]);
    }
  };

  const handlePublish = () => {
    if (!finalRecipe) return;

    const newRecipe = {
      id: `r_${Date.now()}`,
      title: finalRecipe.name,
      description: finalRecipe.description,
      region: finalRecipe.region || region || "Unknown Region",
      cover_image_url: coverImage || `https://source.unsplash.com/featured/?${encodeURIComponent(finalRecipe.name)},food`,
      is_verified: false,
      author_id: currentUser.id,
      likes: 0,
      time_minutes: 30,
      ingredients: finalRecipe.ingredients,
      steps: finalRecipe.steps.map((s: any, i: number) => ({
        id: i + 1,
        step_number: i + 1,
        instruction: s.action,
        detail: s.detail,
        icon: s.icon,
        timerSeconds: s.timerSeconds
      })),
      authenticity_notes: finalRecipe.authenticity_notes || []
    };

    addRecipe(newRecipe);
    navigate('/');
  };

  return (
    <div className="max-w-md mx-auto bg-[#FAF7F2] min-h-screen pb-20 pt-4 px-4">
      <h1 className="text-2xl font-serif font-medium mb-6 text-[#1A1A1A]">Add Recipe</h1>

      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col gap-4"
          >
            <div className="bg-white rounded-2xl border border-[#E5E0D8] p-4 shadow-sm">
              <textarea
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                placeholder="Write your recipe however you want — ingredients, steps, grandma's secrets, messy notes, whatever you have..."
                className="w-full h-48 bg-transparent resize-none focus:outline-none text-[#1A1A1A] placeholder-gray-400"
              />
            </div>

            <input
              type="file"
              accept="image/*"
              className="hidden"
              ref={fileInputRef}
              onChange={handleImageUpload}
            />

            {coverImage ? (
              <div className="relative w-full h-48 rounded-2xl overflow-hidden border border-[#E5E0D8]">
                <img src={coverImage} alt="Cover preview" className="w-full h-full object-cover" />
                <button 
                  onClick={() => setCoverImage(null)}
                  className="absolute top-2 right-2 bg-black/50 text-white p-1.5 rounded-full hover:bg-black/70 transition-colors"
                >
                  <X size={16} />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-center gap-2 w-full py-4 bg-white border border-[#E5E0D8] rounded-xl text-[#1A1A1A] font-medium hover:bg-gray-50 transition-colors shadow-sm"
              >
                <Camera size={20} />
                Add cover photo
              </button>
            )}

            <div className="relative">
              <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                <MapPin size={20} className="text-gray-400" />
              </div>
              <input
                type="text"
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                placeholder="Where is this recipe from? (e.g. Roma, Italia)"
                className="w-full pl-12 pr-4 py-4 bg-white border border-[#E5E0D8] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#C4614A] focus:border-transparent transition-all shadow-sm"
              />
            </div>

            <button
              onClick={handleTransform}
              disabled={!rawText.trim()}
              className="mt-4 flex items-center justify-center gap-2 w-full py-4 bg-[#C4614A] text-white rounded-xl font-medium active:bg-[#A34E3A] transition-colors disabled:opacity-50 disabled:active:bg-[#C4614A] shadow-sm"
            >
              <Sparkles size={20} />
              Let AI transform it →
            </button>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center h-[60vh] gap-6"
          >
            <div className="relative w-24 h-24">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 rounded-full border-4 border-[#E5E0D8] border-t-[#C4614A]"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles size={32} className="text-[#C4614A]" />
              </div>
            </div>
            <motion.p
              key={loadingText}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="text-lg font-serif text-[#1A1A1A] text-center"
            >
              {loadingText}
            </motion.p>
          </motion.div>
        )}

        {step === 3 && generatedRecipe && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col gap-6"
          >
            <div>
              <h2 className="text-2xl font-serif font-medium text-[#1A1A1A] mb-2">Review AI Changes</h2>
              <p className="text-sm text-gray-500">We made some adjustments to format your recipe perfectly. Review and accept them below.</p>
            </div>

            <div className="flex flex-col gap-4">
              {generatedRecipe.ai_changes.map((change: any, index: number) => {
                const isAccepted = acceptedChanges.includes(index);
                return (
                  <div key={index} className={`bg-white rounded-2xl border p-4 shadow-sm transition-colors ${isAccepted ? 'border-[#E5E0D8]' : 'border-gray-200 opacity-60'}`}>
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        {change.type === 'uncertain' && <AlertTriangle size={16} className="text-[#C4614A]" />}
                        <span className="text-sm font-medium text-[#1A1A1A] capitalize">
                          {change.type.replace('_', ' ')}
                        </span>
                      </div>
                      
                      {/* Toggle Switch */}
                      <button 
                        onClick={() => toggleChange(index)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${isAccepted ? 'bg-[#C4614A]' : 'bg-gray-300'}`}
                      >
                        <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isAccepted ? 'translate-x-6' : 'translate-x-1'}`} />
                      </button>
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-3">{change.description}</p>
                    
                    <div className="bg-[#FAF7F2] rounded-lg p-3 text-sm">
                      <div className="line-through text-gray-400 mb-1">{change.original}</div>
                      <div className="text-[#1A1A1A] font-medium">{change.modified}</div>
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={applyChanges}
              className="w-full py-4 bg-[#C4614A] text-white rounded-xl font-medium active:bg-[#A34E3A] transition-colors shadow-sm mt-4"
            >
              Apply selected changes →
            </button>
          </motion.div>
        )}

        {step === 4 && finalRecipe && (
          <motion.div
            key="step4"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col gap-6"
          >
            <div className="bg-white rounded-2xl border border-[#E5E0D8] p-5 shadow-sm">
              <div className="w-full h-48 rounded-xl overflow-hidden mb-6 bg-[#FAF7F2] relative border border-[#E5E0D8]">
                {coverImage ? (
                  <img src={coverImage} alt="Cover" className="w-full h-full object-cover" />
                ) : isGeneratingImage ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-[#C4614A]">
                    <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-[#C4614A] mb-2"></div>
                    <span className="text-xs font-medium mt-2">Generating editorial photo...</span>
                  </div>
                ) : imageError ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-red-500 p-4 text-center">
                    <AlertTriangle size={24} className="mb-2" />
                    <span className="text-xs font-medium">{imageError}</span>
                  </div>
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                    <Camera size={24} />
                  </div>
                )}
              </div>

              <div className="flex items-start justify-between mb-4">
                <h2 className="text-2xl font-serif font-medium text-[#1A1A1A]">{finalRecipe.name}</h2>
                <button className="p-2 text-gray-400 hover:text-[#1A1A1A] transition-colors">
                  <Edit2 size={18} />
                </button>
              </div>
              <p className="text-sm text-gray-500 mb-4">{finalRecipe.region}</p>
              
              <h3 className="font-medium text-[#1A1A1A] mb-2">Ingredients</h3>
              <ul className="space-y-2 mb-6">
                {finalRecipe.ingredients.map((ing: any, i: number) => (
                  <li key={i} className="flex justify-between text-sm border-b border-gray-100 pb-2">
                    <span className="text-[#1A1A1A] flex items-center gap-2">
                      {ing.name}
                      {ing.uncertain && <AlertTriangle size={14} className="text-[#C4614A]" title="Uncertain quantity" />}
                    </span>
                    <span className="text-gray-500">{ing.qty} {ing.unit}</span>
                  </li>
                ))}
              </ul>

              <h3 className="font-medium text-[#1A1A1A] mb-2">Steps ({finalRecipe.steps.length})</h3>
              <div className="space-y-3">
                {finalRecipe.steps.slice(0, 3).map((step: any, i: number) => (
                  <div key={i} className="flex gap-3 items-center bg-[#FAF7F2] p-3 rounded-lg">
                    <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-xs font-medium text-[#C4614A] shrink-0 shadow-sm">
                      {i + 1}
                    </div>
                    <p className="text-sm text-[#1A1A1A]">{step.action}</p>
                  </div>
                ))}
                {finalRecipe.steps.length > 3 && (
                  <p className="text-center text-sm text-gray-500 italic">
                    + {finalRecipe.steps.length - 3} more steps
                  </p>
                )}
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-[#E5E0D8] p-4 shadow-sm flex items-center gap-3">
              <button 
                onClick={() => setRequestVerification(!requestVerification)}
                className={`w-6 h-6 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                  requestVerification ? 'bg-[#C9A84C] border-[#C9A84C]' : 'border-gray-300'
                }`}
              >
                {requestVerification && <CheckCircle size={14} className="text-white" />}
              </button>
              <div>
                <p className="font-medium text-sm text-[#1A1A1A]">Request Verification</p>
                <p className="text-xs text-gray-500">Submit to local experts for the "Verified Local" badge.</p>
              </div>
            </div>

            <button
              onClick={handlePublish}
              disabled={isGeneratingImage}
              className="w-full py-4 bg-[#C4614A] text-white rounded-xl font-medium active:bg-[#A34E3A] transition-colors shadow-sm disabled:opacity-50"
            >
              {isGeneratingImage ? 'Generating Image...' : 'Publish Recipe'}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
