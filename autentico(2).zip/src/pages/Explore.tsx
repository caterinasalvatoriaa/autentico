import React, { useState } from 'react';
import { Search, MapPin, CheckCircle } from 'lucide-react';
import { useAppContext } from '../data/AppContext';
import { Link } from 'react-router-dom';

export default function Explore() {
  const { recipes, users } = useAppContext();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [isMapView, setIsMapView] = useState(false);

  const filters = ['All', 'Italian', 'Japanese', 'Spanish', 'French', 'Mexican'];

  const filteredRecipes = recipes.filter(recipe => {
    if (activeFilter !== 'All' && !recipe.region.toLowerCase().includes(activeFilter.toLowerCase())) {
      return false;
    }
    if (searchQuery && !recipe.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  });

  return (
    <div className="max-w-md mx-auto bg-[#FAF7F2] min-h-screen pb-20 pt-4 px-4">
      {/* Search Bar */}
      <div className="relative mb-4">
        <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
          <Search size={20} className="text-gray-400" />
        </div>
        <input
          type="text"
          placeholder="Search dish, region, ingredient..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-white border border-[#E5E0D8] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#C4614A] focus:border-transparent transition-all"
        />
      </div>

      {/* Filters */}
      <div className="flex gap-2 overflow-x-auto hide-scrollbar mb-6 pb-2">
        {filters.map(filter => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              activeFilter === filter
                ? 'bg-[#1A1A1A] text-white'
                : 'bg-white text-[#1A1A1A] border border-[#E5E0D8] hover:bg-gray-50'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Trending Section */}
      <div className="mb-8">
        <h2 className="text-xl font-serif font-medium mb-4">Most cooked this week</h2>
        <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-4">
          {recipes.slice(0, 3).map(recipe => (
            <Link key={recipe.id} to={`/recipe/${recipe.id}`} className="shrink-0 w-48 group">
              <div className="relative aspect-square rounded-2xl overflow-hidden mb-2">
                <img src={recipe.cover_image_url} alt={recipe.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-3 left-3 right-3">
                  <h3 className="text-white font-serif leading-tight">{recipe.title}</h3>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Map Toggle */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-serif font-medium">Discover</h2>
        <button 
          onClick={() => setIsMapView(!isMapView)}
          className="flex items-center gap-1 text-sm font-medium text-[#C4614A]"
        >
          <MapPin size={16} />
          {isMapView ? 'List View' : 'Map View'}
        </button>
      </div>

      {/* Grid View */}
      {!isMapView && (
        <div className="grid grid-cols-2 gap-4">
          {filteredRecipes.map(recipe => {
            const author = users.find(u => u.id === recipe.author_id);
            return (
              <Link key={recipe.id} to={`/recipe/${recipe.id}`} className="group relative">
                <div className="aspect-square rounded-xl overflow-hidden mb-2 bg-gray-100">
                  <img src={recipe.cover_image_url} alt={recipe.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="flex items-start justify-between gap-1">
                  <h3 className="font-medium text-sm leading-tight line-clamp-2">{recipe.title}</h3>
                  {recipe.is_verified && (
                    <CheckCircle size={14} className="text-[#C9A84C] fill-[#C9A84C]/20 shrink-0 mt-0.5" />
                  )}
                </div>
                <p className="text-xs text-gray-500 mt-1">{recipe.region}</p>
              </Link>
            );
          })}
        </div>
      )}

      {/* Map View Placeholder */}
      {isMapView && (
        <div className="w-full h-96 bg-[#E5E0D8] rounded-2xl flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-30" style={{ backgroundImage: 'radial-gradient(#1A1A1A 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
          <div className="text-center z-10">
            <MapPin size={48} className="text-[#C4614A] mx-auto mb-2" />
            <p className="font-medium text-[#1A1A1A]">Interactive Map</p>
            <p className="text-sm text-gray-500">Explore verified recipes by region</p>
          </div>
        </div>
      )}
    </div>
  );
}
