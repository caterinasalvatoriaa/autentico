import React from 'react';
import { useAppContext } from '../data/AppContext';
import { CheckCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Profile() {
  const { currentUser, recipes } = useAppContext();

  const userRecipes = recipes.filter(r => r.author_id === currentUser.id);

  return (
    <div className="max-w-md mx-auto bg-[#FAF7F2] min-h-screen pb-20 pt-4">
      {/* Header */}
      <div className="px-4 pb-6 bg-white border-b border-[#E5E0D8]">
        <div className="flex flex-col items-center pt-6">
          <div className="relative w-24 h-24 mb-4">
            <img 
              src={currentUser.avatar} 
              alt={currentUser.name} 
              className={`w-full h-full rounded-full object-cover ${currentUser.isVerified ? 'border-2 border-[#C9A84C] p-0.5' : ''}`} 
            />
            {currentUser.isVerified && (
              <div className="absolute bottom-0 right-0 bg-white rounded-full p-0.5 shadow-sm" title="Verified Local">
                <CheckCircle size={20} className="text-[#C9A84C] fill-[#C9A84C]/20" />
              </div>
            )}
          </div>
          
          <h1 className="text-2xl font-serif font-medium text-[#1A1A1A] mb-1">{currentUser.name}</h1>
          <p className="text-sm text-gray-500 mb-1">@{currentUser.username}</p>
          <p className="text-sm font-medium text-[#C4614A] mb-4">{currentUser.region}</p>

          <div className="flex items-center gap-4 text-sm text-[#1A1A1A] mb-6">
            <span className="font-medium">{userRecipes.length} <span className="text-gray-500 font-normal">recipes</span></span>
            <span className="text-gray-300">•</span>
            <span className="font-medium">{currentUser.followers.toLocaleString()} <span className="text-gray-500 font-normal">followers</span></span>
            <span className="text-gray-300">•</span>
            <span className="font-medium">{currentUser.following.toLocaleString()} <span className="text-gray-500 font-normal">following</span></span>
          </div>

          <button className="w-full py-2.5 bg-white border border-[#E5E0D8] rounded-xl text-[#1A1A1A] font-medium hover:bg-gray-50 transition-colors shadow-sm">
            Edit Profile
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-3 gap-1 p-1 mt-2">
        {userRecipes.map(recipe => (
          <Link key={recipe.id} to={`/recipe/${recipe.id}`} className="aspect-square bg-gray-100 relative group">
            <img src={recipe.cover_image_url} alt={recipe.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <span className="text-white font-medium text-xs text-center px-1 line-clamp-2">{recipe.title}</span>
            </div>
          </Link>
        ))}
        {userRecipes.length === 0 && (
          <div className="col-span-3 py-12 text-center text-gray-500 text-sm">
            No recipes yet.
          </div>
        )}
      </div>
    </div>
  );
}
