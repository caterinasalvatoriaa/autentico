import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { useAppContext } from '../data/AppContext';
import RecipeCard from '../components/RecipeCard';

export default function LocalRecipes() {
  const { recipes, users, toggleLike, toggleSave, savedRecipes } = useAppContext();
  const [selectedRegion, setSelectedRegion] = useState('Roma, Italia');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // Filter verified recipes from the selected region
  const localRecipes = recipes.filter(r => r.is_verified && r.region.includes(selectedRegion.split(',')[0]));

  const regions = ['Roma, Italia', 'Napoli, Italia', 'Osaka, Japan', 'Barcelona, Spain'];

  return (
    <div className="max-w-md mx-auto bg-[#FAF7F2] min-h-screen pb-20 pt-4">
      <div className="px-4 mb-6">
        <h1 className="text-3xl font-serif font-medium text-[#1A1A1A] mb-2">Authentic recipes from your area</h1>
        <p className="text-sm text-gray-500 mb-6">Approved by verified locals only</p>

        <div className="relative">
          <button 
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="flex items-center gap-2 text-sm font-medium text-[#1A1A1A] bg-white px-4 py-2 rounded-full border border-[#E5E0D8] shadow-sm"
          >
            Showing recipes from: {selectedRegion}
            <ChevronDown size={16} className={`transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
          </button>

          {isDropdownOpen && (
            <div className="absolute top-full left-0 mt-2 w-64 bg-white border border-[#E5E0D8] rounded-xl shadow-lg z-10 overflow-hidden">
              {regions.map(region => (
                <button
                  key={region}
                  className="w-full text-left px-4 py-3 text-sm hover:bg-gray-50 transition-colors border-b border-gray-100 last:border-0"
                  onClick={() => {
                    setSelectedRegion(region);
                    setIsDropdownOpen(false);
                  }}
                >
                  {region}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-col gap-6">
        {localRecipes.length > 0 ? (
          localRecipes.map(recipe => {
            const author = users.find(u => u.id === recipe.author_id);
            if (!author) return null;
            const isSaved = savedRecipes.includes(recipe.id);

            return (
              <RecipeCard
                key={recipe.id}
                recipe={recipe}
                author={author}
                isSaved={isSaved}
                toggleLike={toggleLike}
                toggleSave={toggleSave}
                showVerifiedBadge={true}
              />
            );
          })
        ) : (
          <div className="px-4 text-center text-gray-500 mt-10">
            <p>No verified recipes found for this region yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
