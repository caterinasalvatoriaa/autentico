import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Users } from 'lucide-react';
import { useAppContext } from '../data/AppContext';
import RecipeCard from '../components/RecipeCard';

export default function FriendsFeed() {
  const { recipes, users, toggleLike, toggleSave, savedRecipes, currentUser } = useAppContext();
  const navigate = useNavigate();

  // Mock following list (in a real app, this would be currentUser.following_ids)
  // Let's assume the current user follows 'u1' and 'u4'
  const followingIds = ['u1', 'u4'];
  
  const friendsRecipes = recipes.filter(r => followingIds.includes(r.author_id));

  return (
    <div className="max-w-md mx-auto bg-[#FAF7F2] min-h-screen pb-20 pt-4">
      <div className="px-4 mb-6">
        <h1 className="text-3xl font-serif font-medium text-[#1A1A1A] mb-2">Friends</h1>
      </div>

      {friendsRecipes.length > 0 ? (
        <div className="flex flex-col gap-6">
          {friendsRecipes.map(recipe => {
            const author = users.find(u => u.id === recipe.author_id);
            if (!author) return null;
            const isSaved = savedRecipes.includes(recipe.id);

            return (
              <RecipeCard
                key={recipe.id}
                recipe={recipe}
                author={author}
                isSaved={isSaved}
                toggleLike={toggleLike}
                toggleSave={toggleSave}
                showFollowingTag={true}
              />
            );
          })}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center h-[60vh] px-6 text-center">
          <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mb-6 shadow-sm border border-[#E5E0D8]">
            <Users size={40} className="text-[#C4614A]" />
          </div>
          <h2 className="text-xl font-serif font-medium text-[#1A1A1A] mb-2">No friends yet</h2>
          <p className="text-gray-500 mb-8">Follow locals to see their recipes here.</p>
          <button 
            onClick={() => navigate('/local')}
            className="px-8 py-3 bg-[#C4614A] text-white rounded-full font-medium active:bg-[#A34E3A] transition-colors"
          >
            Explore Locals
          </button>
        </div>
      )}
    </div>
  );
}
