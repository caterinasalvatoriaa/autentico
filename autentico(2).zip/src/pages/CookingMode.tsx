import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { ChevronLeft, Sparkles } from 'lucide-react';
import AIChatOverlay from '../components/AIChatOverlay';
import StepTimer from '../components/StepTimer';
import { useAppContext } from '../data/AppContext';
import { Recipe, Step } from '../data/mockData';

// Custom Minimal Icons
const PotIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 8h16" />
    <path d="M6 8v8a4 4 0 0 0 4 4h4a4 4 0 0 0 4-4V8" />
    <path d="M8 4v2" />
    <path d="M12 3v3" />
    <path d="M16 4v2" />
    <path d="M2 10h2" />
    <path d="M20 10h2" />
  </svg>
);

const BoilIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 12h16" />
    <path d="M6 12v6a4 4 0 0 0 4 4h4a4 4 0 0 0 4-4v-6" />
    <path d="M8 8v2" />
    <path d="M12 7v3" />
    <path d="M16 8v2" />
    <path d="M2 14h2" />
    <path d="M20 14h2" />
  </svg>
);

const KnifeIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 21h18M5 18l14-14a2 2 0 00-2.8-2.8L2 15v3h3z" />
  </svg>
);

const WhiskIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2v10" />
    <path d="M12 12a4 4 0 0 0-4 4v2a2 2 0 0 0 4 4 2 2 0 0 0 4-4v-2a4 4 0 0 0-4-4z" />
    <path d="M8 16h8" />
  </svg>
);

const PanIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 15h14a2 2 0 0 0 2-2v-2H1v2a2 2 0 0 0 2 2z" />
    <path d="M19 13l4-2" />
  </svg>
);

const ColanderIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2 10h20" />
    <path d="M4 10c0 5.5 3.6 10 8 10s8-4.5 8-10" />
    <path d="M12 4v4" />
    <path d="M8 5v3" />
    <path d="M16 5v3" />
    <circle cx="12" cy="15" r="1" />
    <circle cx="8" cy="14" r="1" />
    <circle cx="16" cy="14" r="1" />
  </svg>
);

const PlateIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10" />
    <circle cx="12" cy="12" r="6" />
  </svg>
);

const SaltIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M8 4h8v16H8zM10 4V2h4v2M12 10v.01M12 14v.01M12 18v.01" />
  </svg>
);

const PastaIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M8 2v20M12 2v20M16 2v20" />
  </svg>
);

const TimerIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="13" r="8" />
    <path d="M12 9v4l2 2M10 2h4M12 2v3" />
  </svg>
);

const CupIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M6 4h12v10a6 6 0 0 1-6 6 6 6 0 0 1-6-6V4zM18 8h2a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-2M6 10h12" />
  </svg>
);

const BowlIcon = () => (
  <svg width="160" height="160" viewBox="0 0 24 24" fill="none" stroke="#C4614A" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2 10h20M4 10c0 5.5 3.6 10 8 10s8-4.5 8-10" />
  </svg>
);

const getStepIcon = (text: string) => {
  const t = text.toLowerCase();
  if (t.includes('cut') || t.includes('chop') || t.includes('slice') || t.includes('dice')) return <KnifeIcon />;
  if (t.includes('boil') || t.includes('rolling')) return <BoilIcon />;
  if (t.includes('salt')) return <SaltIcon />;
  if (t.includes('spaghetti') || t.includes('pasta')) return <PastaIcon />;
  if (t.includes('timer')) return <TimerIcon />;
  if (t.includes('cup') || t.includes('save')) return <CupIcon />;
  if (t.includes('water') || t.includes('fill')) return <PotIcon />;
  if (t.includes('whisk') || t.includes('egg') || t.includes('mix') || t.includes('stir')) return <WhiskIcon />;
  if (t.includes('bowl')) return <BowlIcon />;
  if (t.includes('pan') || t.includes('cook') || t.includes('fry') || t.includes('guanciale') || t.includes('heat')) return <PanIcon />;
  if (t.includes('drain')) return <ColanderIcon />;
  return <PlateIcon />;
};

const getStepDetail = (text: string) => {
  const timeMatch = text.match(/\b(\d+(?:-\d+)?\s*(?:min|minutes|hrs|hours))\b/i);
  if (timeMatch) return `⏱ ${timeMatch[1]}`;
  
  const tempMatch = text.match(/\b(low|medium|high)\s*heat\b/i);
  if (tempMatch) return `🌡 ${tempMatch[0]}`;
  
  const weightMatch = text.match(/\b(\d+(?:\.\d+)?\s*(?:g|kg|ml|l|oz|lb|cups?|tbsp|tsp|liters?))\b/i);
  if (weightMatch) return `⚖ ${weightMatch[1]}`;

  return null;
};

const getParsedSeconds = (step: Step) => {
  if (step.timerSeconds) return step.timerSeconds;
  
  const text = `${step.instruction} ${step.detail || ''}`;
  const minMatch = text.match(/\b(\d+(?:\.\d+)?)\s*(?:min|minutes|m)\b/i);
  if (minMatch) return Math.round(parseFloat(minMatch[1]) * 60);
  
  const secMatch = text.match(/\b(\d+)\s*(?:sec|seconds|s)\b/i);
  if (secMatch) return parseInt(secMatch[1], 10);
  
  return null;
};

export default function CookingMode() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { recipes } = useAppContext();
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [showAIChat, setShowAIChat] = useState(false);
  const [direction, setDirection] = useState(0);

  useEffect(() => {
    const found = recipes.find(r => r.id === id);
    setRecipe(found || null);
    setLoading(false);
  }, [id, recipes]);

  if (loading || !recipe) {
    return (
      <div className="flex justify-center items-center h-screen bg-[#FAF7F2]">
        <div className="animate-spin rounded-full h-8 w-8 border-t border-b border-[#1A1A1A]"></div>
      </div>
    );
  }

  const steps = recipe.steps;
  const currentStep = steps[currentStepIndex];
  const detail = currentStep.detail || getStepDetail(currentStep.instruction);
  const timerSeconds = getParsedSeconds(currentStep);

  const paginate = (newDirection: number) => {
    if (currentStepIndex + newDirection < 0 || currentStepIndex + newDirection >= steps.length) return;
    setDirection(newDirection);
    setCurrentStepIndex(currentStepIndex + newDirection);
  };

  const handleDragEnd = (e: any, { offset }: PanInfo) => {
    const swipe = offset.x;
    const swipeThreshold = 50;
    if (swipe < -swipeThreshold) {
      paginate(1);
    } else if (swipe > swipeThreshold) {
      paginate(-1);
    }
  };

  const handleTap = (e: React.MouseEvent) => {
    const x = e.clientX;
    const width = window.innerWidth;
    if (x < width * 0.25) paginate(-1);
    else if (x > width * 0.75) paginate(1);
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? '100%' : '-100%',
    }),
    center: {
      x: 0,
    },
    exit: (direction: number) => ({
      x: direction < 0 ? '100%' : '-100%',
    }),
  };

  return (
    <div className="fixed inset-0 bg-[#FAF7F2] text-[#1A1A1A] overflow-hidden flex flex-col font-sans">
      
      {/* Progress Dots */}
      <div className="absolute top-0 left-0 right-0 p-6 flex justify-center gap-2 z-30 pointer-events-none">
        {steps.map((_, idx) => (
          <div 
            key={idx} 
            className={`w-2 h-2 rounded-full transition-colors duration-300 ${idx <= currentStepIndex ? 'bg-[#C4614A]' : 'bg-[#E5E0D8]'}`}
          />
        ))}
      </div>

      {/* Main Content Area */}
      <div className="flex-1 relative overflow-hidden" onClick={handleTap}>
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={currentStepIndex}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.2, ease: "easeInOut" }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={1}
            onDragEnd={handleDragEnd}
            className="absolute inset-0 flex flex-col items-center justify-center p-8 cursor-grab active:cursor-grabbing"
          >
             <div className="flex-1 flex items-end justify-center pb-8 w-full">
                {getStepIcon(currentStep.icon || currentStep.instruction)}
             </div>
             <div className="flex-1 flex flex-col items-center justify-start text-center w-full max-w-2xl px-4">
                <h2 className="text-4xl md:text-5xl font-serif leading-tight mb-6 text-[#1A1A1A]">
                  {currentStep.instruction}
                </h2>
                {detail && !timerSeconds && (
                  <div className="bg-[#E5E0D8]/60 text-[#555] px-5 py-2 rounded-full text-sm md:text-base font-mono tracking-wide">
                    {detail}
                  </div>
                )}
                {timerSeconds && (
                  <div onClick={(e) => e.stopPropagation()} className="cursor-default">
                    <StepTimer initialSeconds={timerSeconds} />
                  </div>
                )}
             </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom Bar */}
      <div className="h-24 px-6 flex items-center justify-between border-t border-[#E5E0D8] bg-[#FAF7F2] z-30 relative">
        <button 
          onClick={() => navigate(-1)} 
          className="p-3 text-[#1A1A1A] hover:opacity-50 transition-opacity"
        >
          <ChevronLeft size={28} strokeWidth={1.5} />
        </button>
        
        <div className="font-serif text-lg tracking-widest text-[#1A1A1A]/40">
          {String(currentStepIndex + 1).padStart(2, '0')} / {String(steps.length).padStart(2, '0')}
        </div>

        <button 
          onClick={() => setShowAIChat(true)} 
          className="flex items-center gap-2 px-5 py-2.5 rounded-full border border-[#C4614A] text-[#C4614A] font-medium text-sm hover:bg-[#C4614A] hover:text-white transition-colors"
        >
          <Sparkles size={16} />
          <span className="hidden sm:inline">Looks right?</span>
        </button>
      </div>

      {showAIChat && (
        <AIChatOverlay
          recipe={recipe as any}
          currentStep={currentStep as any}
          onClose={() => setShowAIChat(false)}
        />
      )}
    </div>
  );
}
