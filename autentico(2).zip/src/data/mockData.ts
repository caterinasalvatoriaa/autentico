export interface User {
  id: string;
  username: string;
  name: string;
  avatar: string;
  region: string;
  isVerified: boolean;
  bio: string;
  followers: number;
  following: number;
}

export interface Ingredient {
  name: string;
  qty: string;
  unit: string;
}

export interface Step {
  id: number;
  step_number: number;
  instruction: string;
  detail: string | null;
  icon: string;
  timerSeconds?: number;
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  region: string;
  cover_image_url: string;
  is_verified: boolean;
  author_id: string;
  likes: number;
  time_minutes: number;
  ingredients: Ingredient[];
  steps: Step[];
  authenticity_notes: string[];
}

export const users: User[] = [
  {
    id: "u1",
    username: "marco_romano",
    name: "Marco Romano",
    avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=200&auto=format&fit=crop",
    region: "Roma, Italia 🇮🇹",
    isVerified: true,
    bio: "Roman born and raised. Pasta is my religion.",
    followers: 1205,
    following: 150
  },
  {
    id: "u2",
    username: "yuki_osaka",
    name: "Yuki Tanaka",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=200&auto=format&fit=crop",
    region: "Osaka, Japan 🇯🇵",
    isVerified: true,
    bio: "Street food enthusiast. Dashi master.",
    followers: 890,
    following: 210
  },
  {
    id: "u3",
    username: "sofia_bcn",
    name: "Sofia Garcia",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop",
    region: "Barcelona, Spain 🇪🇸",
    isVerified: false,
    bio: "Tapas lover. Always exploring local markets.",
    followers: 340,
    following: 89
  },
  {
    id: "u4",
    username: "elena_napoli",
    name: "Elena Esposito",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=200&auto=format&fit=crop",
    region: "Napoli, Italia 🇮🇹",
    isVerified: true,
    bio: "Nonna taught me everything. Slow cooking only.",
    followers: 2100,
    following: 55
  }
];

export const initialRecipes: Recipe[] = [
  {
    id: "r1",
    title: "Authentic Carbonara",
    description: "The real Roman way. No cream, no garlic, just 4 ingredients.",
    region: "Roma, Italia",
    cover_image_url: "https://images.unsplash.com/photo-1612889837130-9b4b9b9b9b9b?q=80&w=800&auto=format&fit=crop",
    is_verified: true,
    author_id: "u1",
    likes: 1245,
    time_minutes: 20,
    ingredients: [
      { name: "Spaghetti", qty: "400", unit: "g" },
      { name: "Guanciale", qty: "150", unit: "g" },
      { name: "Pecorino Romano", qty: "50", unit: "g" },
      { name: "Egg yolks", qty: "4", unit: "large" },
      { name: "Black pepper", qty: "to taste", unit: "" }
    ],
    steps: [
      { id: 1, step_number: 1, instruction: "Cut 150g guanciale into thick strips.", detail: "⚖ 150g", icon: "knife" },
      { id: 2, step_number: 2, instruction: "Place guanciale in a cold pan.", detail: null, icon: "pan" },
      { id: 3, step_number: 3, instruction: "Cook on medium heat until crispy.", detail: "🌡 medium heat", icon: "fire", timerSeconds: 300 },
      { id: 4, step_number: 4, instruction: "Remove pan from heat. Set aside.", detail: null, icon: "pan" },
      { id: 5, step_number: 5, instruction: "Put 4 egg yolks in a bowl.", detail: "⚖ 4 yolks", icon: "bowl" },
      { id: 6, step_number: 6, instruction: "Add 50g grated Pecorino Romano.", detail: "⚖ 50g", icon: "bowl" },
      { id: 7, step_number: 7, instruction: "Add plenty of black pepper.", detail: null, icon: "salt" },
      { id: 8, step_number: 8, instruction: "Whisk into a thick paste.", detail: null, icon: "whisk" },
      { id: 9, step_number: 9, instruction: "Fill a pot with water.", detail: null, icon: "pot" },
      { id: 10, step_number: 10, instruction: "Bring water to a rolling boil.", detail: null, icon: "pot" },
      { id: 11, step_number: 11, instruction: "Add 50g of coarse salt.", detail: "⚖ 50g", icon: "salt" },
      { id: 12, step_number: 12, instruction: "Drop in 400g of spaghetti.", detail: "⚖ 400g", icon: "pasta" },
      { id: 13, step_number: 13, instruction: "Set a timer for 8 minutes.", detail: "⏱ 8 min", icon: "timer", timerSeconds: 480 },
      { id: 14, step_number: 14, instruction: "Save one cup of pasta water.", detail: "⚖ 1 cup", icon: "cup" },
      { id: 15, step_number: 15, instruction: "Drain the spaghetti.", detail: null, icon: "drain" },
      { id: 16, step_number: 16, instruction: "Toss hot pasta in the guanciale pan.", detail: null, icon: "pan" },
      { id: 17, step_number: 17, instruction: "Stir in the egg mixture off-heat.", detail: null, icon: "mix" },
      { id: 18, step_number: 18, instruction: "Add pasta water for a creamy sauce.", detail: null, icon: "water" }
    ],
    authenticity_notes: [
      "Never use cream. The creaminess comes from the emulsion of egg, cheese, and starchy pasta water.",
      "Guanciale is essential. Pancetta is a substitute, but bacon is too smoky.",
      "Pecorino Romano provides the necessary sharp, salty flavor."
    ]
  },
  {
    id: "r2",
    title: "Cacio e Pepe",
    description: "The magic of cheese, pepper, and starchy water.",
    region: "Roma, Italia",
    cover_image_url: "https://images.unsplash.com/photo-1643237146914-2794121a8d03?q=80&w=800&auto=format&fit=crop",
    is_verified: true,
    author_id: "u1",
    likes: 980,
    time_minutes: 15,
    ingredients: [
      { name: "Tonnarelli or Spaghetti", qty: "400", unit: "g" },
      { name: "Pecorino Romano", qty: "200", unit: "g" },
      { name: "Black peppercorns", qty: "1", unit: "tbsp" }
    ],
    steps: [
      { id: 1, step_number: 1, instruction: "Toast crushed peppercorns in a dry pan.", detail: "🌡 medium heat", icon: "pan" },
      { id: 2, step_number: 2, instruction: "Boil water in a wide pan.", detail: null, icon: "pot" },
      { id: 3, step_number: 3, instruction: "Add pasta to the boiling water.", detail: "⚖ 400g", icon: "pasta" },
      { id: 4, step_number: 4, instruction: "Grate 200g Pecorino Romano very finely.", detail: "⚖ 200g", icon: "bowl" },
      { id: 5, step_number: 5, instruction: "Add a ladle of pasta water to pepper.", detail: null, icon: "cup" },
      { id: 6, step_number: 6, instruction: "Transfer half-cooked pasta to the pepper pan.", detail: null, icon: "pan" },
      { id: 7, step_number: 7, instruction: "Finish cooking pasta in the pan.", detail: null, icon: "pan" },
      { id: 8, step_number: 8, instruction: "Mix Pecorino with warm water to form paste.", detail: null, icon: "whisk" },
      { id: 9, step_number: 9, instruction: "Remove pan from heat completely.", detail: null, icon: "fire" },
      { id: 10, step_number: 10, instruction: "Vigorously stir in the cheese paste.", detail: null, icon: "mix" },
      { id: 11, step_number: 11, instruction: "Toss until a glossy cream forms.", detail: null, icon: "mix" },
      { id: 12, step_number: 12, instruction: "Serve immediately on warm plates.", detail: null, icon: "serve" }
    ],
    authenticity_notes: [
      "The temperature of the water added to the cheese is crucial. Too hot and it will clump.",
      "Cooking the pasta risotto-style in the pan releases more starch for the sauce."
    ]
  },
  {
    id: "r3",
    title: "Authentic Takoyaki",
    description: "Crispy outside, gooey inside. Osaka's soul food.",
    region: "Osaka, Japan",
    cover_image_url: "https://images.unsplash.com/photo-1574484284002-952d92456975?q=80&w=800&auto=format&fit=crop",
    is_verified: true,
    author_id: "u2",
    likes: 850,
    time_minutes: 40,
    ingredients: [
      { name: "Takoyaki flour mix", qty: "200", unit: "g" },
      { name: "Eggs", qty: "2", unit: "large" },
      { name: "Dashi stock", qty: "600", unit: "ml" },
      { name: "Boiled octopus", qty: "150", unit: "g" },
      { name: "Tenkasu (tempura scraps)", qty: "30", unit: "g" },
      { name: "Green onion", qty: "2", unit: "stalks" }
    ],
    steps: [
      { id: 1, step_number: 1, instruction: "Whisk eggs and cold dashi stock together.", detail: "⚖ 600ml", icon: "whisk" },
      { id: 2, step_number: 2, instruction: "Gradually whisk in the takoyaki flour.", detail: "⚖ 200g", icon: "whisk" },
      { id: 3, step_number: 3, instruction: "Cut octopus into bite-sized chunks.", detail: null, icon: "knife" },
      { id: 4, step_number: 4, instruction: "Finely chop the green onions.", detail: null, icon: "knife" },
      { id: 5, step_number: 5, instruction: "Heat the takoyaki pan.", detail: "🌡 high heat", icon: "fire" },
      { id: 6, step_number: 6, instruction: "Generously oil every hole in the pan.", detail: null, icon: "pan" },
      { id: 7, step_number: 7, instruction: "Pour batter to overfill the holes slightly.", detail: null, icon: "bowl" },
      { id: 8, step_number: 8, instruction: "Drop one octopus piece into each hole.", detail: null, icon: "hand" },
      { id: 9, step_number: 9, instruction: "Sprinkle tenkasu and green onions over everything.", detail: null, icon: "hand" },
      { id: 10, step_number: 10, instruction: "Wait 2 minutes for the bottom to cook.", detail: "⏱ 2 min", icon: "timer" },
      { id: 11, step_number: 11, instruction: "Use a pick to turn each ball 90 degrees.", detail: null, icon: "hand" },
      { id: 12, step_number: 12, instruction: "Pour a little more batter if needed.", detail: null, icon: "bowl" },
      { id: 13, step_number: 13, instruction: "Turn them again to form perfect spheres.", detail: null, icon: "hand" },
      { id: 14, step_number: 14, instruction: "Cook until golden brown and crispy.", detail: null, icon: "timer" },
      { id: 15, step_number: 15, instruction: "Serve with sauce, mayo, and bonito flakes.", detail: null, icon: "serve" }
    ],
    authenticity_notes: [
      "The batter must be very thin, almost watery, to achieve the gooey center.",
      "A cast-iron takoyaki pan yields the best crispy exterior."
    ]
  },
  {
    id: "r4",
    title: "Pan con Tomate",
    description: "The simplest, most perfect Catalan breakfast.",
    region: "Barcelona, Spain",
    cover_image_url: "https://images.unsplash.com/photo-1620088191205-02058b8686d1?q=80&w=800&auto=format&fit=crop",
    is_verified: false,
    author_id: "u3",
    likes: 420,
    time_minutes: 5,
    ingredients: [
      { name: "Rustic bread (Coca or Ciabatta)", qty: "4", unit: "slices" },
      { name: "Very ripe tomatoes (Ramallet)", qty: "2", unit: "" },
      { name: "Garlic clove", qty: "1", unit: "" },
      { name: "Extra virgin olive oil", qty: "to taste", unit: "" },
      { name: "Flaky sea salt", qty: "to taste", unit: "" }
    ],
    steps: [
      { id: 1, step_number: 1, instruction: "Slice the bread into thick pieces.", detail: null, icon: "knife" },
      { id: 2, step_number: 2, instruction: "Toast the bread until golden and crispy.", detail: null, icon: "fire" },
      { id: 3, step_number: 3, instruction: "Cut the garlic clove in half.", detail: null, icon: "knife" },
      { id: 4, step_number: 4, instruction: "Rub the raw garlic lightly over the toast.", detail: null, icon: "hand" },
      { id: 5, step_number: 5, instruction: "Cut the ripe tomatoes in half horizontally.", detail: null, icon: "knife" },
      { id: 6, step_number: 6, instruction: "Rub the tomato halves vigorously onto the bread.", detail: null, icon: "hand" },
      { id: 7, step_number: 7, instruction: "Discard the empty tomato skins.", detail: null, icon: "hand" },
      { id: 8, step_number: 8, instruction: "Drizzle generously with extra virgin olive oil.", detail: null, icon: "hand" },
      { id: 9, step_number: 9, instruction: "Sprinkle with flaky sea salt.", detail: null, icon: "salt" },
      { id: 10, step_number: 10, instruction: "Serve immediately while the bread is crunchy.", detail: null, icon: "serve" }
    ],
    authenticity_notes: [
      "Do not blend the tomatoes. They must be rubbed directly onto the bread.",
      "The order is crucial: garlic, tomato, oil, then salt."
    ]
  },
  {
    id: "r5",
    title: "Ragù Napoletano",
    description: "The Sunday sauce. Slow-cooked meat and tomatoes.",
    region: "Napoli, Italia",
    cover_image_url: "https://images.unsplash.com/photo-1598866594230-a70186201114?q=80&w=800&auto=format&fit=crop",
    is_verified: true,
    author_id: "u4",
    likes: 2100,
    time_minutes: 360,
    ingredients: [
      { name: "Beef chuck roast", qty: "500", unit: "g" },
      { name: "Pork ribs", qty: "500", unit: "g" },
      { name: "San Marzano tomatoes (passata)", qty: "1.5", unit: "L" },
      { name: "Onions", qty: "2", unit: "large" },
      { name: "Red wine", qty: "1", unit: "glass" },
      { name: "Olive oil", qty: "4", unit: "tbsp" }
    ],
    steps: [
      { id: 1, step_number: 1, instruction: "Finely chop the onions.", detail: null, icon: "knife" },
      { id: 2, step_number: 2, instruction: "Heat olive oil in a large heavy pot.", detail: "🌡 medium heat", icon: "pot" },
      { id: 3, step_number: 3, instruction: "Brown the meat on all sides.", detail: null, icon: "pan" },
      { id: 4, step_number: 4, instruction: "Add the chopped onions to the pot.", detail: null, icon: "pot" },
      { id: 5, step_number: 5, instruction: "Cook until onions are translucent.", detail: null, icon: "timer" },
      { id: 6, step_number: 6, instruction: "Pour in the red wine.", detail: null, icon: "cup" },
      { id: 7, step_number: 7, instruction: "Let the alcohol evaporate completely.", detail: null, icon: "fire" },
      { id: 8, step_number: 8, instruction: "Pour in the tomato passata.", detail: "⚖ 1.5L", icon: "pot" },
      { id: 9, step_number: 9, instruction: "Add a pinch of salt.", detail: null, icon: "salt" },
      { id: 10, step_number: 10, instruction: "Bring to a gentle simmer.", detail: null, icon: "pot" },
      { id: 11, step_number: 11, instruction: "Lower the heat to the absolute minimum.", detail: "🌡 low heat", icon: "fire" },
      { id: 12, step_number: 12, instruction: "Partially cover the pot with a lid.", detail: null, icon: "pot" },
      { id: 13, step_number: 13, instruction: "Let it simmer ('pippiare') for 6 hours.", detail: "⏱ 6 hrs", icon: "timer" },
      { id: 14, step_number: 14, instruction: "Stir occasionally to prevent burning.", detail: null, icon: "mix" },
      { id: 15, step_number: 15, instruction: "Serve the sauce with pasta, meat separately.", detail: null, icon: "serve" }
    ],
    authenticity_notes: [
      "The sauce must 'pippiare' (bubble very slowly) for at least 6 hours.",
      "The meat is traditionally served as a second course, not mixed with the pasta."
    ]
  }
];
