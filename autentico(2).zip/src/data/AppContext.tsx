import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User, Recipe, users, initialRecipes } from './mockData';

interface AppContextType {
  currentUser: User;
  users: User[];
  recipes: Recipe[];
  addRecipe: (recipe: Recipe) => void;
  toggleLike: (recipeId: string) => void;
  toggleSave: (recipeId: string) => void;
  savedRecipes: string[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [allUsers] = useState<User[]>(users);
  const [allRecipes, setAllRecipes] = useState<Recipe[]>(initialRecipes);
  const [savedRecipes, setSavedRecipes] = useState<string[]>([]);
  
  // Hardcode current user to Sofia for demo
  const currentUser = allUsers.find(u => u.id === 'u3')!;

  const addRecipe = (recipe: Recipe) => {
    setAllRecipes(prev => [recipe, ...prev]);
  };

  const toggleLike = (recipeId: string) => {
    setAllRecipes(prev => prev.map(r => {
      if (r.id === recipeId) {
        // Simple toggle logic for demo
        const isLiked = false; // We don't track individual likes in this simple mock
        return { ...r, likes: r.likes + 1 };
      }
      return r;
    }));
  };

  const toggleSave = (recipeId: string) => {
    setSavedRecipes(prev => 
      prev.includes(recipeId) 
        ? prev.filter(id => id !== recipeId)
        : [...prev, recipeId]
    );
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      users: allUsers,
      recipes: allRecipes,
      addRecipe,
      toggleLike,
      toggleSave,
      savedRecipes
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}
