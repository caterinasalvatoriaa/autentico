import { useEffect, useState, useRef } from 'react';
import { motion } from 'motion/react';
import { X, Mic, MicOff, Loader2 } from 'lucide-react';
import { GoogleGenAI, Modality } from '@google/genai';

interface AIVoiceOverlayProps {
  recipe: any;
  currentStep: any;
  onClose: () => void;
}

export default function AIVoiceOverlay({ recipe, currentStep, onClose }: AIVoiceOverlayProps) {
  const [isConnecting, setIsConnecting] = useState(true);
  const [isConnected, setIsConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const processorNodeRef = useRef<ScriptProcessorNode | null>(null);

  useEffect(() => {
    connectLiveAPI();
    return () => {
      disconnectLiveAPI();
    };
  }, []);

  const connectLiveAPI = async () => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const systemInstruction = `You are a warm, encouraging, and non-judgmental local grandmother guiding the user through a recipe. 
      The recipe is "${recipe.title}". 
      The user is currently on step ${currentStep.step_number}: "${currentStep.instruction}".
      Answer their questions specifically about this step or recipe. Keep it conversational and helpful.`;

      const sessionPromise = ai.live.connect({
        model: "gemini-2.5-flash-native-audio-preview-09-2025",
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsConnected(true);
            startAudioCapture(sessionPromise);
          },
          onmessage: async (message: any) => {
             const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
             if (base64Audio) {
               playAudio(base64Audio);
             }
          },
          onerror: (err) => {
            console.error(err);
            setError("Connection error. Please try again.");
            setIsConnecting(false);
          },
          onclose: () => {
            setIsConnected(false);
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: "Kore" } },
          },
          systemInstruction,
        },
      });

      sessionRef.current = sessionPromise;

    } catch (err) {
      console.error(err);
      setError("Failed to connect to AI.");
      setIsConnecting(false);
    }
  };

  const startAudioCapture = async (sessionPromise: Promise<any>) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      
      const audioContext = new AudioContext({ sampleRate: 16000 });
      audioContextRef.current = audioContext;
      
      const source = audioContext.createMediaStreamSource(stream);
      sourceNodeRef.current = source;
      
      const processor = audioContext.createScriptProcessor(4096, 1, 1);
      processorNodeRef.current = processor;
      
      processor.onaudioprocess = (e) => {
        if (isMuted) return;
        const inputData = e.inputBuffer.getChannelData(0);
        const pcmData = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          pcmData[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7FFF;
        }
        
        // Convert to base64
        const buffer = new ArrayBuffer(pcmData.length * 2);
        const view = new DataView(buffer);
        for (let i = 0; i < pcmData.length; i++) {
          view.setInt16(i * 2, pcmData[i], true);
        }
        
        const base64 = btoa(String.fromCharCode(...new Uint8Array(buffer)));
        
        sessionPromise.then((session) => {
          session.sendRealtimeInput({
            media: { data: base64, mimeType: 'audio/pcm;rate=16000' }
          });
        });
      };
      
      source.connect(processor);
      processor.connect(audioContext.destination);
      
    } catch (err) {
      console.error("Audio capture error:", err);
      setError("Microphone access denied.");
    }
  };

  const playAudio = async (base64Audio: string) => {
    try {
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      // The audio is 24kHz PCM 16-bit mono
      const audioCtx = new AudioContext({ sampleRate: 24000 });
      const audioBuffer = audioCtx.createBuffer(1, bytes.length / 2, 24000);
      const channelData = audioBuffer.getChannelData(0);
      
      const dataView = new DataView(bytes.buffer);
      for (let i = 0; i < bytes.length / 2; i++) {
        channelData[i] = dataView.getInt16(i * 2, true) / 0x7FFF;
      }
      
      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);
      source.start();
    } catch (err) {
      console.error("Audio playback error:", err);
    }
  };

  const disconnectLiveAPI = () => {
    if (sessionRef.current) {
      sessionRef.current.then((session: any) => session.close());
    }
    if (processorNodeRef.current) {
      processorNodeRef.current.disconnect();
    }
    if (sourceNodeRef.current) {
      sourceNodeRef.current.disconnect();
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-sm p-6"
    >
      <div className="bg-[var(--color-cream)] rounded-3xl w-full max-w-sm p-8 flex flex-col items-center relative shadow-2xl border border-white/20">
        <button onClick={onClose} className="absolute top-4 right-4 p-2 text-gray-500 hover:text-black transition-colors">
          <X size={24} />
        </button>
        
        <div className="w-24 h-24 bg-[var(--color-terracotta)] rounded-full flex items-center justify-center text-white font-serif font-bold text-4xl mb-6 shadow-lg relative">
          N
          {isConnected && !isMuted && (
            <motion.div
              className="absolute inset-0 rounded-full border-4 border-[var(--color-terracotta)]"
              animate={{ scale: [1, 1.2, 1], opacity: [1, 0, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
            />
          )}
        </div>
        
        <h3 className="font-serif font-bold text-2xl mb-2 text-[var(--color-ink)]">Nonna AI</h3>
        
        {isConnecting ? (
          <div className="flex items-center gap-2 text-[var(--color-olive)]">
            <Loader2 size={16} className="animate-spin" />
            <p className="font-medium">Connecting...</p>
          </div>
        ) : error ? (
          <p className="text-red-500 font-medium text-center">{error}</p>
        ) : (
          <p className="text-[var(--color-olive)] font-medium text-center mb-8">
            {isMuted ? "Microphone muted" : "Listening... Speak to Nonna"}
          </p>
        )}

        <button
          onClick={toggleMute}
          disabled={!isConnected}
          className={`p-6 rounded-full shadow-lg transition-all ${
            isMuted 
              ? 'bg-gray-200 text-gray-500 hover:bg-gray-300' 
              : 'bg-[var(--color-terracotta)] text-white hover:bg-[var(--color-terracotta-dark)] hover:scale-105'
          }`}
        >
          {isMuted ? <MicOff size={32} /> : <Mic size={32} />}
        </button>
      </div>
    </motion.div>
  );
}
