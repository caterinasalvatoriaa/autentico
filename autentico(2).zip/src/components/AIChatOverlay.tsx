import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, Camera, Loader2, Check } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

interface AIChatOverlayProps {
  recipe: any;
  currentStep: any;
  onClose: () => void;
}

export default function AIChatOverlay({ recipe, currentStep, onClose }: AIChatOverlayProps) {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai'; text: string; image?: string }[]>([
    { role: 'ai', text: `I'm here to help with step ${currentStep.step_number}. What do you need?` }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSend = async () => {
    if (!input.trim() && !selectedImage) return;

    const userMsg = { role: 'user' as const, text: input, image: selectedImage || undefined };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setSelectedImage(null);
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: (import.meta as any).env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || '' });
      
      const systemInstruction = `You are a calm, focused, and precise cooking assistant (like a Thermomix guide). 
      The recipe is "${recipe.title}". 
      The user is currently on step ${currentStep.step_number}: "${currentStep.instruction}".
      Answer their questions specifically about this step. Keep it very short, specific, and reassuring. No long paragraphs.`;

      let response;

      if (userMsg.image) {
        const base64Data = userMsg.image.split(',')[1];
        const mimeType = userMsg.image.match(/data:(.*?);base64/)?.[1] || 'image/jpeg';
        
        response = await ai.models.generateContent({
          model: 'gemini-3.1-pro-preview',
          contents: {
            parts: [
              { inlineData: { data: base64Data, mimeType } },
              { text: userMsg.text || "Does this look right?" }
            ]
          },
          config: { systemInstruction }
        });
      } else {
        response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: userMsg.text,
          config: { systemInstruction }
        });
      }

      setMessages((prev) => [...prev, { role: 'ai', text: response.text || "I'm not sure." }]);
    } catch (error) {
      console.error(error);
      setMessages((prev) => [...prev, { role: 'ai', text: "I'm having trouble understanding right now. Can you try again?" }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <AnimatePresence>
      <motion.div className="fixed inset-0 z-50 flex flex-col justify-end pointer-events-none">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-black/40 backdrop-blur-sm pointer-events-auto" 
          onClick={onClose} 
        />
        
        <motion.div 
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="bg-[#1A1A1A] text-[#FAF7F2] w-full max-h-[85vh] rounded-t-3xl p-6 flex flex-col pointer-events-auto shadow-2xl font-sans relative"
        >
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-serif text-xl text-[#FAF7F2]/80">Chef Assistant</h3>
            <button onClick={onClose} className="text-[#FAF7F2]/50 hover:text-white transition-colors">
              <X size={24} strokeWidth={1.5} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto space-y-6 mb-6 pr-2 custom-scrollbar">
            {messages.map((msg, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl p-4 ${
                    msg.role === 'user'
                      ? 'bg-[#333] text-white rounded-tr-sm'
                      : 'bg-transparent border border-[#333] text-[#FAF7F2] rounded-tl-sm'
                  }`}
                >
                  {msg.image && (
                    <img src={msg.image} alt="Upload" className="w-full rounded-xl mb-3 object-cover max-h-48" />
                  )}
                  <p className="font-sans leading-relaxed text-sm md:text-base">{msg.text}</p>
                </div>
              </motion.div>
            ))}
            {isTyping && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                <div className="bg-transparent border border-[#333] rounded-2xl rounded-tl-sm p-4 flex gap-2">
                  <div className="w-1.5 h-1.5 bg-[#FAF7F2]/50 rounded-full animate-bounce" />
                  <div className="w-1.5 h-1.5 bg-[#FAF7F2]/50 rounded-full animate-bounce delay-100" />
                  <div className="w-1.5 h-1.5 bg-[#FAF7F2]/50 rounded-full animate-bounce delay-200" />
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="mt-auto">
            {selectedImage && (
              <div className="mb-3 relative inline-block">
                <img src={selectedImage} alt="Preview" className="h-16 rounded-lg border border-[#333] object-cover" />
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-2 -right-2 bg-[#333] rounded-full p-1 text-white hover:bg-[#444]"
                >
                  <X size={12} />
                </button>
              </div>
            )}
            
            <div className="flex items-center gap-3 bg-[#222] rounded-full p-1.5 border border-[#333] focus-within:border-[#555] transition-colors">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="p-2.5 text-[#FAF7F2]/60 hover:text-white hover:bg-[#333] rounded-full transition-colors"
              >
                <Camera size={20} strokeWidth={1.5} />
              </button>
              <input
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                ref={fileInputRef}
                onChange={handleImageUpload}
              />
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about this step..."
                className="flex-1 bg-transparent py-2 focus:outline-none font-sans text-sm text-white placeholder-[#FAF7F2]/30"
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() && !selectedImage || isTyping}
                className="p-2.5 bg-[#FAF7F2] text-[#1A1A1A] rounded-full disabled:opacity-50 hover:bg-white transition-colors"
              >
                {isTyping ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
              </button>
            </div>

            <button 
              onClick={onClose} 
              className="mt-4 w-full py-4 bg-[#333] hover:bg-[#444] text-white rounded-2xl font-medium flex justify-center items-center gap-2 transition-colors text-sm tracking-wide"
            >
              Got it <Check size={16} strokeWidth={2} />
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
