import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Heart, Bookmark, Send, CheckCircle } from 'lucide-react';
import { Recipe, User } from '../data/mockData';

interface RecipeCardProps {
  recipe: Recipe;
  author: User;
  isSaved: boolean;
  toggleLike: (id: string) => void;
  toggleSave: (id: string) => void;
  showVerifiedBadge?: boolean;
  showFollowingTag?: boolean;
}

export default function RecipeCard({
  recipe,
  author,
  isSaved,
  toggleLike,
  toggleSave,
  showVerifiedBadge,
  showFollowingTag
}: RecipeCardProps) {
  const navigate = useNavigate();

  return (
    <article className="mb-8 bg-white border border-[#E5E0D8] rounded-2xl overflow-hidden shadow-sm mx-4 flex flex-col">
      <div className="flex w-full aspect-[2/1] sm:aspect-[2.5/1]">
        {/* Left side: square food photo (40% width) */}
        <div 
          className="w-[40%] h-full relative cursor-pointer"
          onClick={() => navigate(`/recipe/${recipe.id}`)}
        >
          <img 
            src={recipe.cover_image_url} 
            alt={recipe.title} 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          {showVerifiedBadge && recipe.is_verified && (
            <div className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full flex items-center gap-1 shadow-sm">
              <CheckCircle size={12} className="text-[#C9A84C] fill-[#C9A84C]/20" />
              <span className="text-[10px] font-medium text-[#1A1A1A] uppercase tracking-wider">Verified Local</span>
            </div>
          )}
          {showFollowingTag && (
            <div className="absolute top-2 left-2 bg-[#1A1A1A]/80 backdrop-blur-sm px-2 py-1 rounded-full flex items-center gap-1 shadow-sm">
              <span className="text-[10px] font-medium text-white uppercase tracking-wider">Following</span>
            </div>
          )}
        </div>

        {/* Right side: details */}
        <div className="w-[60%] p-4 flex flex-col justify-between">
          <div>
            <h2 
              className="text-xl sm:text-2xl font-serif font-medium leading-tight mb-1 cursor-pointer hover:text-[#C4614A] transition-colors line-clamp-2"
              onClick={() => navigate(`/recipe/${recipe.id}`)}
            >
              {recipe.title}
            </h2>
            <div className="flex items-center gap-1 mb-1">
              <span className="text-sm font-medium text-[#1A1A1A]">{author.username}</span>
              {author.isVerified && (
                <CheckCircle size={12} className="text-[#C9A84C] fill-[#C9A84C]/20" />
              )}
            </div>
            <p className="text-xs text-gray-500 mb-2 truncate">{recipe.region}</p>
            <p className="text-xs text-gray-600 mb-3">
              {recipe.ingredients.length} ingredients · {recipe.steps.length} steps
            </p>
          </div>
          
          <Link 
            to={`/recipe/${recipe.id}/cook`}
            className="inline-flex items-center justify-center py-2 px-4 bg-[#C4614A] text-white text-sm rounded-full font-medium active:bg-[#A34E3A] transition-colors self-start"
          >
            Cook →
          </Link>
        </div>
      </div>

      {/* Bottom strip */}
      <div className="px-4 py-3 border-t border-[#E5E0D8] flex items-center justify-between bg-gray-50/50">
        <div className="flex items-center gap-4">
          <button onClick={() => toggleLike(recipe.id)} className="transition-transform active:scale-90 flex items-center gap-1.5">
            <Heart size={20} className={recipe.likes > 0 ? "fill-[#C4614A] text-[#C4614A]" : "text-[#1A1A1A]"} />
            <span className="text-xs font-medium text-gray-600">{recipe.likes.toLocaleString()}</span>
          </button>
          <button className="transition-transform active:scale-90">
            <Send size={18} className="text-[#1A1A1A]" />
          </button>
        </div>
        <button onClick={() => toggleSave(recipe.id)} className="transition-transform active:scale-90">
          <Bookmark size={20} className={isSaved ? "fill-[#1A1A1A] text-[#1A1A1A]" : "text-[#1A1A1A]"} />
        </button>
      </div>
    </article>
  );
}
