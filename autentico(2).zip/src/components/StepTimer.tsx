import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, BellRing } from 'lucide-react';
import { motion } from 'framer-motion';

export default function StepTimer({ initialSeconds }: { initialSeconds: number }) {
  const [secondsLeft, setSecondsLeft] = useState(initialSeconds);
  const [isRunning, setIsRunning] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Create audio element for the alarm
    audioRef.current = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    setSecondsLeft(initialSeconds);
    setIsRunning(false);
    setIsFinished(false);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  }, [initialSeconds]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((prev) => prev - 1);
      }, 1000);
    } else if (secondsLeft === 0 && isRunning) {
      setIsRunning(false);
      setIsFinished(true);
      if (audioRef.current) {
        audioRef.current.play().catch(e => console.log("Audio play failed:", e));
      }
    }
    return () => clearInterval(interval);
  }, [isRunning, secondsLeft]);

  const toggleTimer = () => setIsRunning(!isRunning);
  const resetTimer = () => {
    setIsRunning(false);
    setSecondsLeft(initialSeconds);
    setIsFinished(false);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;

  return (
    <div className={`mt-8 flex flex-col items-center p-6 rounded-3xl border-2 transition-colors ${isFinished ? 'bg-[#C4614A]/10 border-[#C4614A]' : 'bg-white border-[#E5E0D8]'}`}>
      <div className={`text-5xl font-mono font-medium tracking-tighter mb-6 ${isFinished ? 'text-[#C4614A] animate-pulse' : 'text-[#1A1A1A]'}`}>
        {String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}
      </div>
      <div className="flex gap-4">
        <button 
          onClick={toggleTimer} 
          disabled={isFinished}
          className="w-14 h-14 rounded-full bg-[#C4614A] text-white flex items-center justify-center hover:bg-[#A34E3A] transition-colors shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isRunning ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" className="ml-1" />}
        </button>
        <button 
          onClick={resetTimer} 
          className="w-14 h-14 rounded-full bg-[#E5E0D8] text-[#1A1A1A] flex items-center justify-center hover:bg-[#D5D0C8] transition-colors"
        >
          <RotateCcw size={24} />
        </button>
      </div>
      {isFinished && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }} 
          animate={{ opacity: 1, y: 0 }} 
          className="mt-4 text-[#C4614A] font-medium flex items-center gap-2"
        >
          <BellRing size={18} className="animate-bounce" /> Time's up!
        </motion.div>
      )}
    </div>
  );
}
