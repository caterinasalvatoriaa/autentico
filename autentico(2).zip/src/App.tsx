/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Home, MapPin, Users, User as UserIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AppProvider } from './data/AppContext';
import HomeFeed from './pages/HomeFeed';
import LocalRecipes from './pages/LocalRecipes';
import FriendsFeed from './pages/FriendsFeed';
import AddRecipe from './pages/AddRecipe';
import Profile from './pages/Profile';
import RecipeDetail from './pages/RecipeDetail';
import CookingMode from './pages/CookingMode';

function BottomNav() {
  const location = useLocation();
  const isCookingMode = location.pathname.includes('/cook');
  
  if (isCookingMode) return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#FAF7F2]/90 backdrop-blur-md border-t border-[#E5E0D8] pb-safe z-40">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto">
        <Link to="/" className={`p-3 transition-colors ${location.pathname === '/' ? 'text-[#C4614A]' : 'text-[#BBBBBB] hover:text-[#C4614A]'}`}>
          <Home size={24} strokeWidth={location.pathname === '/' ? 2.5 : 1.5} />
        </Link>
        <Link to="/local" className={`p-3 transition-colors ${location.pathname === '/local' ? 'text-[#C4614A]' : 'text-[#BBBBBB] hover:text-[#C4614A]'}`}>
          <MapPin size={24} strokeWidth={location.pathname === '/local' ? 2.5 : 1.5} />
        </Link>
        <Link to="/friends" className={`p-3 transition-colors ${location.pathname === '/friends' ? 'text-[#C4614A]' : 'text-[#BBBBBB] hover:text-[#C4614A]'}`}>
          <Users size={24} strokeWidth={location.pathname === '/friends' ? 2.5 : 1.5} />
        </Link>
        <Link to="/profile" className={`p-3 transition-colors ${location.pathname === '/profile' ? 'text-[#C4614A]' : 'text-[#BBBBBB] hover:text-[#C4614A]'}`}>
          <UserIcon size={24} strokeWidth={location.pathname === '/profile' ? 2.5 : 1.5} />
        </Link>
      </div>
    </nav>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Router>
        <div className="min-h-screen bg-[#FAF7F2] text-[#1A1A1A] font-sans pb-16">
          <Routes>
            <Route path="/" element={<HomeFeed />} />
            <Route path="/local" element={<LocalRecipes />} />
            <Route path="/friends" element={<FriendsFeed />} />
            <Route path="/add" element={<AddRecipe />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/recipe/:id" element={<RecipeDetail />} />
            <Route path="/recipe/:id/cook" element={<CookingMode />} />
          </Routes>
          <BottomNav />
        </div>
      </Router>
    </AppProvider>
  );
}
